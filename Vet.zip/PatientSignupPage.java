package Hospital;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Random;

public class PatientSignupPage extends JFrame implements ActionListener {
    JLabel idLabel, nameLabel, ageLabel, genderLabel, phoneLabel, emailLabel, addressLabel, passLabel;
    JTextField idField, nameField, ageField, phoneField, emailField, addressField;
    JPasswordField passField;
    JComboBox<String> genderCombo;
    JButton signupBtn, backBtn;

    public PatientSignupPage() {
        setTitle("Patient Signup");
        setSize(450, 600);
        setLocation(450, 100);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel heading = new JLabel("Patient Signup");
        heading.setFont(new Font("Arial", Font.BOLD, 24));
        heading.setBounds(140, 20, 200, 30);
        add(heading);

        idLabel = new JLabel("Patient ID:");
        idLabel.setBounds(50, 70, 100, 25);
        add(idLabel);

        idField = new JTextField(generatePatientId());
        idField.setBounds(160, 70, 200, 25);
        idField.setEditable(false);
        add(idField);

        nameLabel = new JLabel("Full Name:");
        nameLabel.setBounds(50, 110, 100, 25);
        add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(160, 110, 200, 25);
        add(nameField);

        ageLabel = new JLabel("Age:");
        ageLabel.setBounds(50, 150, 100, 25);
        add(ageLabel);

        ageField = new JTextField();
        ageField.setBounds(160, 150, 200, 25);
        add(ageField);

        genderLabel = new JLabel("Gender:");
        genderLabel.setBounds(50, 190, 100, 25);
        add(genderLabel);

        genderCombo = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        genderCombo.setBounds(160, 190, 200, 25);
        add(genderCombo);

        phoneLabel = new JLabel("Phone Number:");
        phoneLabel.setBounds(50, 230, 120, 25);
        add(phoneLabel);

        phoneField = new JTextField();
        phoneField.setBounds(160, 230, 200, 25);
        add(phoneField);

        emailLabel = new JLabel("Email:");
        emailLabel.setBounds(50, 270, 100, 25);
        add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(160, 270, 200, 25);
        add(emailField);

        addressLabel = new JLabel("Address:");
        addressLabel.setBounds(50, 310, 100, 25);
        add(addressLabel);

        addressField = new JTextField();
        addressField.setBounds(160, 310, 200, 25);
        add(addressField);

        passLabel = new JLabel("Password:");
        passLabel.setBounds(50, 350, 100, 25);
        add(passLabel);

        passField = new JPasswordField();
        passField.setBounds(160, 350, 200, 25);
        add(passField);

        signupBtn = new JButton("Signup");
        signupBtn.setBounds(100, 410, 90, 35);
        signupBtn.addActionListener(this);
        add(signupBtn);

        backBtn = new JButton("Back");
        backBtn.setBounds(220, 410, 90, 35);
        backBtn.addActionListener(this);
        add(backBtn);

        setVisible(true);
    }

    private String generatePatientId() {
        Random rnd = new Random();
        int number = rnd.nextInt(999999);
        return String.format("%06d", number);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == signupBtn) {
            String patientId = idField.getText();
            String name = nameField.getText().trim();
            String ageText = ageField.getText().trim();
            String gender = (String) genderCombo.getSelectedItem();
            String phone = phoneField.getText().trim();
            String email = emailField.getText().trim();
            String address = addressField.getText().trim();
            String password = new String(passField.getPassword());

            // Validate required fields
            if (name.isEmpty() || ageText.isEmpty() || phone.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all mandatory fields (Name, Age, Phone, Password).");
                return;
            }

            int age;
            try {
                age = Integer.parseInt(ageText);
                if (age <= 0) {
                    JOptionPane.showMessageDialog(this, "Age must be a positive number.");
                    return;
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid age. Please enter a valid number.");
                return;
            }

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_", "root", "Pritha123!");

                String query = "INSERT INTO patient (patient_id, name, age, gender, phone, email, address, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement pst = con.prepareStatement(query);
                pst.setString(1, patientId);
                pst.setString(2, name);
                pst.setInt(3, age);
                pst.setString(4, gender);
                pst.setString(5, phone);
                pst.setString(6, email);
                pst.setString(7, address);
                pst.setString(8, password);

                int rowCount = pst.executeUpdate();

                if (rowCount > 0) {
                    JOptionPane.showMessageDialog(this, "Signup successful! Please log in.");
                    setVisible(false);
                    new PatientLoginPage(); // ✅ Redirects to login page after signup
                } else {
                    JOptionPane.showMessageDialog(this, "Signup failed. Please try again.");
                }

                con.close();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }

        } else if (e.getSource() == backBtn) {
            setVisible(false);
            new Index(); // ✅ Goes back to the Index page
        }
    }

    public static void main(String[] args) {
        new PatientSignupPage();
    }
}
