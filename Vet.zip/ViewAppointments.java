package Hospital;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class ViewAppointments extends JFrame {

    private String patientId;
    private JTextArea textArea;

    public ViewAppointments(String patientId) {
        this.patientId = patientId;

        setTitle("My Appointments - Patient ID: " + patientId);
        setSize(650, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Arial", Font.PLAIN, 16));
        JScrollPane scrollPane = new JScrollPane(textArea);

        add(scrollPane, BorderLayout.CENTER);

        loadAppointments();

        setVisible(true);
    }

    private void loadAppointments() {
        try (ConnectionClass cc = new ConnectionClass()) {
            PreparedStatement pst = cc.con.prepareStatement(
                    "SELECT appointment_date, appointment_time, type, pet_category, status " +
                            "FROM appointment WHERE patient_id = ? ORDER BY appointment_date, appointment_time"
            );
            pst.setString(1, patientId);

            ResultSet rs = pst.executeQuery();

            StringBuilder past = new StringBuilder();
            StringBuilder future = new StringBuilder();
            boolean hasPast = false, hasFuture = false;

            LocalDate today = LocalDate.now();
            LocalTime now = LocalTime.now();

            while (rs.next()) {
                LocalDate date = rs.getDate("appointment_date").toLocalDate();
                Time sqlTime = rs.getTime("appointment_time");
                LocalTime time = (sqlTime != null) ? sqlTime.toLocalTime() : LocalTime.MIDNIGHT;

                String type = rs.getString("type");
                String petCategory = rs.getString("pet_category");
                String status = rs.getString("status");

                String appointmentInfo =
                        "Type: " + type + "\n" +
                                "Pet Category: " + petCategory + "\n" +
                                "Date: " + date + "\n" +
                                "Time: " + time + "\n" +
                                "Status: " + status + "\n" +
                                "-------------------------------\n";

                boolean isPastByDate = date.isBefore(today);
                boolean isPastByTime = date.isEqual(today) && time.isBefore(now);

                if (status.equalsIgnoreCase("completed") || isPastByDate || isPastByTime) {
                    past.append(appointmentInfo);
                    hasPast = true;
                } else {
                    future.append(appointmentInfo);
                    hasFuture = true;
                }
            }

            StringBuilder all = new StringBuilder();

            if (hasFuture) {
                all.append("🔷 FUTURE APPOINTMENTS:\n\n").append(future).append("\n");
            } else {
                all.append("🔷 FUTURE APPOINTMENTS:\n\nNo upcoming appointments.\n\n");
            }

            if (hasPast) {
                all.append("🔶 PAST APPOINTMENTS:\n\n").append(past);
            } else {
                all.append("🔶 PAST APPOINTMENTS:\n\nNo past appointments.");
            }

            textArea.setText(all.toString());

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading appointments", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
