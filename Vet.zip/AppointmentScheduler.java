package Hospital;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.time.ZoneId;
import java.util.Date;
import java.util.Properties;

import org.jdatepicker.impl.*;

public class AppointmentScheduler extends JFrame implements ActionListener {
    private String patientId;
    private JComboBox<String> doctorComboBox;
    private JDatePickerImpl datePicker;
    private JComboBox<String> timeComboBox;
    private JComboBox<String> petCategoryComboBox;
    private JComboBox<String> typeComboBox;
    private JCheckBox reminderCheckBox;
    private JButton btnSubmit, btnBack;

    public AppointmentScheduler(String patientId) {
        this.patientId = patientId;
        setTitle("Appointment Scheduler");
        setSize(450, 350);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(8, 2, 5, 5));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        add(new JLabel("Select Doctor:"));
        doctorComboBox = new JComboBox<>();
        loadDoctors();
        add(doctorComboBox);

        add(new JLabel("Appointment Date:"));
        datePicker = createDatePicker();
        add(datePicker);

        add(new JLabel("Appointment Time:"));
        String[] times = {"09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00"};
        timeComboBox = new JComboBox<>(times);
        add(timeComboBox);

        add(new JLabel("Pet Category:"));
        petCategoryComboBox = new JComboBox<>(new String[]{"Dog", "Cat", "Bird", "Other"});
        add(petCategoryComboBox);

        add(new JLabel("Type:"));
        typeComboBox = new JComboBox<>(new String[]{"Regular", "Emergency"});
        add(typeComboBox);

        add(new JLabel("Set Reminder:"));
        reminderCheckBox = new JCheckBox();
        add(reminderCheckBox);

        btnSubmit = new JButton("Book Appointment");
        btnSubmit.addActionListener(this);
        add(btnSubmit);

        btnBack = new JButton("Back");
        btnBack.addActionListener(e -> this.dispose());
        add(btnBack);

        setVisible(true);
    }

    private void loadDoctors() {
        try {
            ConnectionClass cc = new ConnectionClass();
            ResultSet rs = cc.stm.executeQuery("SELECT name FROM doctor");
            while (rs.next()) {
                doctorComboBox.addItem(rs.getString("name"));
            }
            cc.con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to load doctors: " + e.getMessage());
        }
    }

    private JDatePickerImpl createDatePicker() {
        UtilDateModel model = new UtilDateModel();
        model.setSelected(true);
        Properties p = new Properties();
        p.put("text.today", "Today");
        p.put("text.month", "Month");
        p.put("text.year", "Year");
        JDatePanelImpl datePanel = new JDatePanelImpl(model, p);
        return new JDatePickerImpl(datePanel, new DateLabelFormatter());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String doctorName = (String) doctorComboBox.getSelectedItem();
        Date selectedDate = (Date) datePicker.getModel().getValue();
        String timeStr = (String) timeComboBox.getSelectedItem();
        String petCategory = (String) petCategoryComboBox.getSelectedItem();
        String type = (String) typeComboBox.getSelectedItem();
        boolean reminder = reminderCheckBox.isSelected();

        if (doctorName == null || selectedDate == null || timeStr == null || petCategory == null || type == null) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        LocalDate appointmentDate = selectedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        if (appointmentDate.isBefore(LocalDate.now())) {
            JOptionPane.showMessageDialog(this, "Appointment date cannot be in the past", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Validate time format
            LocalTime.parse(timeStr); // throws exception if invalid

            ConnectionClass cc = new ConnectionClass();

            // Get doctor ID from name
            PreparedStatement pstDoctor = cc.con.prepareStatement("SELECT doctor_id FROM doctor WHERE name = ?");
            pstDoctor.setString(1, doctorName);
            ResultSet rsDoctor = pstDoctor.executeQuery();

            String doctorId = null;
            if (rsDoctor.next()) {
                doctorId = rsDoctor.getString("doctor_id");
            } else {
                JOptionPane.showMessageDialog(this, "Selected doctor not found in database", "Error", JOptionPane.ERROR_MESSAGE);
                cc.con.close();
                return;
            }

            // NEW CHECK: Prevent patient from having two appointments at the same date and time (any doctor)
            PreparedStatement pstCheckPatient = cc.con.prepareStatement(
                    "SELECT * FROM appointment WHERE patient_id = ? AND appointment_date = ? AND appointment_time = ?"
            );
            pstCheckPatient.setString(1, patientId);
            pstCheckPatient.setString(2, appointmentDate.toString());
            pstCheckPatient.setString(3, timeStr);
            ResultSet rsCheckPatient = pstCheckPatient.executeQuery();

            if (rsCheckPatient.next()) {
                JOptionPane.showMessageDialog(this, "You already have an appointment at this date and time. Please select another time.", "Error", JOptionPane.ERROR_MESSAGE);
                cc.con.close();
                return;
            }

            // Optional: If you want, you can also check if the doctor is booked at that time:
            // But since it's not asked, you can keep or remove this block.
            /*
            PreparedStatement pstCheckDoctor = cc.con.prepareStatement(
                "SELECT * FROM appointment WHERE doctor_id = ? AND appointment_date = ? AND appointment_time = ?"
            );
            pstCheckDoctor.setString(1, doctorId);
            pstCheckDoctor.setString(2, appointmentDate.toString());
            pstCheckDoctor.setString(3, timeStr);
            ResultSet rsCheckDoctor = pstCheckDoctor.executeQuery();

            if (rsCheckDoctor.next()) {
                JOptionPane.showMessageDialog(this, "Selected doctor is not available at this time. Please select another time or doctor.", "Error", JOptionPane.ERROR_MESSAGE);
                cc.con.close();
                return;
            }
            */

            // Insert appointment
            PreparedStatement pst = cc.con.prepareStatement(
                    "INSERT INTO appointment (patient_id, doctor_id, appointment_date, appointment_time, pet_category, type, reminder) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            pst.setString(1, patientId);
            pst.setString(2, doctorId);
            pst.setString(3, appointmentDate.toString());
            pst.setString(4, timeStr);
            pst.setString(5, petCategory);
            pst.setString(6, type.toLowerCase());
            pst.setBoolean(7, reminder);

            int result = pst.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Appointment booked successfully!");
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to book appointment", "Error", JOptionPane.ERROR_MESSAGE);
            }

            cc.con.close();
        } catch (DateTimeParseException dtpe) {
            JOptionPane.showMessageDialog(this, "Invalid time format (use HH:mm)", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
