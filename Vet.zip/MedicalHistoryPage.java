package Hospital;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class MedicalHistoryPage extends JFrame {

    public MedicalHistoryPage(String patientId) {
        setTitle("Medical History");
        setSize(700, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JTextArea historyArea = new JTextArea();
        historyArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        historyArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(historyArea);
        add(scrollPane, BorderLayout.CENTER);

        try {
            ConnectionClass cc = new ConnectionClass();
            String sql = "SELECT * FROM medical_records WHERE patient_id = ? ORDER BY date DESC";
            PreparedStatement pst = cc.con.prepareStatement(sql);
            pst.setString(1, patientId);
            ResultSet rs = pst.executeQuery();

            StringBuilder history = new StringBuilder();
            while (rs.next()) {
                history.append("Date: ").append(rs.getString("date")).append("\n")
                        .append("Doctor: ").append(rs.getString("doctor_name")).append("\n")
                        .append("Pet Name: ").append(rs.getString("pet_name")).append("\n")
                        .append("Category: ").append(rs.getString("pet_category")).append("\n")
                        .append("Diagnosis: ").append(rs.getString("diagnosis")).append("\n")
                        .append("Prescription: ").append(rs.getString("prescription")).append("\n")
                        .append("----------------------------------------------------------\n");
            }

            if (history.length() == 0) {
                history.append("No medical history found.");
            }

            historyArea.setText(history.toString());
            cc.con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        setVisible(true);
    }
}
