package Hospital;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AddDoctorPage extends JFrame implements ActionListener {

    JTextField tfId, tfName, tfAge, tfSpec, tfPhone, tfEmail, tfCity, tfPassword;
    JComboBox<String> genderBox;
    JButton submitBtn, backBtn;

    public AddDoctorPage() {
        setTitle("Add New Doctor");
        setSize(500, 500);
        setLocation(300, 100);
        setLayout(null);
        setResizable(false);

        JLabel l1 = new JLabel("Add Doctor Details");
        l1.setFont(new Font("Arial", Font.BOLD, 20));
        l1.setBounds(150, 10, 300, 30);
        add(l1);

        JLabel lblId = new JLabel("Doctor ID:");
        lblId.setBounds(50, 60, 100, 25);
        add(lblId);

        tfId = new JTextField();
        tfId.setBounds(180, 60, 200, 25);
        add(tfId);

        JLabel lblName = new JLabel("Name:");
        lblName.setBounds(50, 100, 100, 25);
        add(lblName);

        tfName = new JTextField();
        tfName.setBounds(180, 100, 200, 25);
        add(tfName);

        JLabel lblAge = new JLabel("Age:");
        lblAge.setBounds(50, 140, 100, 25);
        add(lblAge);

        tfAge = new JTextField();
        tfAge.setBounds(180, 140, 200, 25);
        add(tfAge);

        JLabel lblGender = new JLabel("Gender:");
        lblGender.setBounds(50, 180, 100, 25);
        add(lblGender);

        genderBox = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        genderBox.setBounds(180, 180, 200, 25);
        add(genderBox);

        JLabel lblSpec = new JLabel("Specialization:");
        lblSpec.setBounds(50, 220, 100, 25);
        add(lblSpec);

        tfSpec = new JTextField();
        tfSpec.setBounds(180, 220, 200, 25);
        add(tfSpec);

        JLabel lblPhone = new JLabel("Phone:");
        lblPhone.setBounds(50, 260, 100, 25);
        add(lblPhone);

        tfPhone = new JTextField();
        tfPhone.setBounds(180, 260, 200, 25);
        add(tfPhone);

        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setBounds(50, 300, 100, 25);
        add(lblEmail);

        tfEmail = new JTextField();
        tfEmail.setBounds(180, 300, 200, 25);
        add(tfEmail);

        JLabel lblCity = new JLabel("City:");
        lblCity.setBounds(50, 340, 100, 25);
        add(lblCity);

        tfCity = new JTextField();
        tfCity.setBounds(180, 340, 200, 25);
        add(tfCity);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setBounds(50, 380, 100, 25);
        add(lblPassword);

        tfPassword = new JTextField();
        tfPassword.setBounds(180, 380, 200, 25);
        add(tfPassword);

        submitBtn = new JButton("Submit");
        submitBtn.setBounds(100, 420, 100, 30);
        submitBtn.setBackground(Color.BLACK);
        submitBtn.setForeground(Color.WHITE);
        submitBtn.addActionListener(this);
        add(submitBtn);

        backBtn = new JButton("Back");
        backBtn.setBounds(220, 420, 100, 30);
        backBtn.setBackground(Color.BLACK);
        backBtn.setForeground(Color.WHITE);
        backBtn.addActionListener(this);
        add(backBtn);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == submitBtn) {
            String id = tfId.getText();
            String name = tfName.getText();
            String age = tfAge.getText();
            String gender = (String) genderBox.getSelectedItem();
            String spec = tfSpec.getText();
            String phone = tfPhone.getText();
            String email = tfEmail.getText();
            String city = tfCity.getText();
            String Password = tfPassword.getText();

            try {
                ConnectionClass obj = new ConnectionClass();
                String query = "INSERT INTO doctor VALUES('" + id + "', '" + name + "', " + age + ", '" + gender + "', '" + spec + "', '" + phone + "', '" + email + "', '" + city + "','" + Password + "')";
                obj.stm.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Doctor added successfully.");
                setVisible(false);
                new AdminHomePage();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
                e.printStackTrace();
            }
        }

        if (ae.getSource() == backBtn) {
            setVisible(false);
            new AdminHomePage();
        }
    }

    public static void main(String[] args) {
        new AddDoctorPage();
    }
}
