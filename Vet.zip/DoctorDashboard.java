package Hospital;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DoctorDashboard extends JFrame implements ActionListener {
    private String doctorId;
    private JTable appointmentTable;
    private JButton btnCompleteAppointment, btnLogout;
    private JTextArea txtAdvice, txtPrescription;

    public DoctorDashboard(String doctorId) {
        this.doctorId = doctorId;

        setTitle("Doctor Dashboard - ID: " + doctorId);
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Header
        JLabel heading = new JLabel("Doctor Dashboard - Welcome " + doctorId, JLabel.CENTER);
        heading.setFont(new Font("Arial", Font.BOLD, 22));
        heading.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(heading, BorderLayout.NORTH);

        // Appointment Table
        appointmentTable = new JTable();
        JScrollPane tableScroll = new JScrollPane(appointmentTable);
        add(tableScroll, BorderLayout.CENTER);

        // Bottom panel
        JPanel bottomPanel = new JPanel(new GridLayout(2, 1));

        JPanel formPanel = new JPanel(new GridLayout(1, 4, 10, 10));
        txtAdvice = new JTextArea("Write advice here...");
        txtPrescription = new JTextArea("Write prescription here...");

        formPanel.add(new JScrollPane(txtAdvice));
        formPanel.add(new JScrollPane(txtPrescription));

        btnCompleteAppointment = new JButton("Complete Appointment");
        btnCompleteAppointment.addActionListener(this);
        btnCompleteAppointment.setEnabled(false); // initially disabled

        btnLogout = new JButton("Logout");
        btnLogout.addActionListener(this);

        formPanel.add(btnCompleteAppointment);
        formPanel.add(btnLogout);
        bottomPanel.add(formPanel);
        add(bottomPanel, BorderLayout.SOUTH);

        // Disable form
        setFormEnabled(false);

        // Enable form when a row is selected
        appointmentTable.getSelectionModel().addListSelectionListener(e -> {
            boolean rowSelected = appointmentTable.getSelectedRow() != -1;
            setFormEnabled(rowSelected);
        });

        fetchAppointments();
        setVisible(true);
    }

    private void setFormEnabled(boolean enabled) {
        txtAdvice.setEnabled(enabled);
        txtPrescription.setEnabled(enabled);
        btnCompleteAppointment.setEnabled(enabled);
    }

    private void fetchAppointments() {
        try (ConnectionClass cc = new ConnectionClass();
             PreparedStatement pst = cc.con.prepareStatement(
                     "SELECT a.appointment_id, a.patient_id, p.name AS patient_name, a.appointment_date, a.appointment_time, a.pet_category, a.type " +
                             "FROM appointment a JOIN patient p ON a.patient_id = p.patient_id WHERE a.doctor_id = ?"
             )) {
            pst.setString(1, doctorId);
            ResultSet rs = pst.executeQuery();

            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Appointment ID");
            model.addColumn("Patient ID");
            model.addColumn("Patient Name");
            model.addColumn("Date");
            model.addColumn("Time");
            model.addColumn("Pet Category");
            model.addColumn("Type");

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("appointment_id"),
                        rs.getString("patient_id"),
                        rs.getString("patient_name"),
                        rs.getDate("appointment_date"),
                        rs.getTime("appointment_time"),
                        rs.getString("pet_category"),
                        rs.getString("type")
                });
            }

            appointmentTable.setModel(model);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void completeAppointment() {
        int selectedRow = appointmentTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an appointment.");
            return;
        }

        int appointmentId = (int) appointmentTable.getValueAt(selectedRow, 0);
        String patientId = (String) appointmentTable.getValueAt(selectedRow, 1);
        String petCategory = (String) appointmentTable.getValueAt(selectedRow, 5);
        String type = (String) appointmentTable.getValueAt(selectedRow, 6); // This can be used for pet name if needed

        String advice = txtAdvice.getText().trim();
        String prescription = txtPrescription.getText().trim();

        if (advice.isEmpty() || prescription.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in both advice and prescription.");
            return;
        }

        try (ConnectionClass cc = new ConnectionClass()) {
            // Get doctor name
            String doctorName = "";
            try (PreparedStatement psDoctor = cc.con.prepareStatement("SELECT name FROM doctor WHERE doctor_id = ?")) {
                psDoctor.setString(1, doctorId);
                ResultSet rsDoctor = psDoctor.executeQuery();
                if (rsDoctor.next()) {
                    doctorName = rsDoctor.getString("name");
                }
            }

            // Insert medical record
            try (PreparedStatement psInsert = cc.con.prepareStatement(
                    "INSERT INTO medical_records (patient_id, doctor_name, pet_name, pet_category, diagnosis, prescription, date) VALUES (?, ?, ?, ?, ?, ?, CURDATE())"
            )) {
                psInsert.setString(1, patientId);
                psInsert.setString(2, doctorName);
                psInsert.setString(3, type); // Assuming 'type' is used for pet name
                psInsert.setString(4, petCategory);
                psInsert.setString(5, advice);
                psInsert.setString(6, prescription);
                psInsert.executeUpdate();
            }

            // Delete appointment
            try (PreparedStatement psDelete = cc.con.prepareStatement("DELETE FROM appointment WHERE appointment_id = ?")) {
                psDelete.setInt(1, appointmentId);
                psDelete.executeUpdate();
            }

            JOptionPane.showMessageDialog(this, "Appointment completed and medical record saved.");
            fetchAppointments();
            txtAdvice.setText("Write advice here...");
            txtPrescription.setText("Write prescription here...");
            setFormEnabled(false);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnCompleteAppointment) {
            completeAppointment();
        } else if (e.getSource() == btnLogout) {
            setVisible(false);
            new LoginPage(); // Adjust as needed
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DoctorDashboard("D001"));
    }
}
