package Hospital;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;

public class PatientDashboard extends JFrame implements ActionListener {
    private String patientId;
    private JButton btnBookAppointment, btnViewAppointments, btnMedicineCorner, btnMedicalHistory, btnLogout;

    public PatientDashboard(String patientId) {
        this.patientId = patientId;

        setTitle("Patient Dashboard - ID: " + patientId);
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.DARK_GRAY);
        JLabel welcomeLabel = new JLabel("Welcome, Patient ID: " + patientId);
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 22));
        headerPanel.add(welcomeLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Buttons
        JPanel centerPanel = new JPanel(new GridLayout(5, 1, 15, 15));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(40, 180, 40, 180));

        btnBookAppointment = new JButton("Book Appointment");
        btnBookAppointment.addActionListener(this);
        centerPanel.add(btnBookAppointment);

        btnViewAppointments = new JButton("View My Appointments");
        btnViewAppointments.addActionListener(this);
        centerPanel.add(btnViewAppointments);

        btnMedicineCorner = new JButton("Medicine Corner");
        btnMedicineCorner.addActionListener(this);
        centerPanel.add(btnMedicineCorner);

        btnMedicalHistory = new JButton("Medical History");
        btnMedicalHistory.addActionListener(this);
        centerPanel.add(btnMedicalHistory);

        btnLogout = new JButton("Logout");
        btnLogout.addActionListener(this);
        centerPanel.add(btnLogout);

        add(centerPanel, BorderLayout.CENTER);

        checkReminders();
        setVisible(true);
    }

    private void checkReminders() {
        try {
            ConnectionClass cc = new ConnectionClass();
            String sql = "SELECT appointment_date, appointment_time, type, pet_category " +
                    "FROM appointment WHERE patient_id = ? AND reminder = 1 AND " +
                    "(appointment_date > CURDATE() OR (appointment_date = CURDATE() AND appointment_time > CURTIME()))";
            PreparedStatement pst = cc.con.prepareStatement(sql);
            pst.setString(1, patientId);
            ResultSet rs = pst.executeQuery();

            StringBuilder reminders = new StringBuilder();
            while (rs.next()) {
                reminders.append("Reminder: ")
                        .append(rs.getString("type")).append(" appointment for your ")
                        .append(rs.getString("pet_category")).append(" on ")
                        .append(rs.getString("appointment_date")).append(" at ")
                        .append(rs.getString("appointment_time")).append("\n");
            }
            cc.con.close();

            if (reminders.length() > 0) {
                JOptionPane.showMessageDialog(this, reminders.toString(), "Appointment Reminders", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnBookAppointment) {
            new AppointmentScheduler(patientId);
        } else if (e.getSource() == btnViewAppointments) {
            new ViewAppointments(patientId);
        } else if (e.getSource() == btnMedicineCorner) {
            new MedicineCorner(patientId);
        } else if (e.getSource() == btnMedicalHistory) {
            new MedicalHistoryPage(patientId);
        } else if (e.getSource() == btnLogout) {
            setVisible(false);
            new PatientLoginPage();
        }
    }

    public static void main(String[] args) {
        new PatientDashboard("P123");
    }
}
