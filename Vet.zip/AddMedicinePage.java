package Hospital;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AddMedicinePage extends JFrame implements ActionListener {

    JLabel lblId, lblName, lblType, lblPrice, lblDescription, lblQuantity, lblExpiry;
    JTextField tfId, tfName, tfType, tfPrice, tfQuantity, tfExpiry;
    JTextArea taDescription;
    JButton addBtn, backBtn;

    public AddMedicinePage() {
        setTitle("Add New Medicine");
        setSize(450, 500);
        setLocation(400, 150);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Labels
        lblId = new JLabel("Medicine ID:");
        lblId.setBounds(30, 30, 120, 25);
        add(lblId);

        lblName = new JLabel("Name:");
        lblName.setBounds(30, 70, 120, 25);
        add(lblName);

        lblType = new JLabel("Type:");
        lblType.setBounds(30, 110, 120, 25);
        add(lblType);

        lblPrice = new JLabel("Price:");
        lblPrice.setBounds(30, 150, 120, 25);
        add(lblPrice);

        lblDescription = new JLabel("Description:");
        lblDescription.setBounds(30, 190, 120, 25);
        add(lblDescription);

        lblQuantity = new JLabel("Quantity:");
        lblQuantity.setBounds(30, 310, 120, 25);
        add(lblQuantity);

        lblExpiry = new JLabel("Expiry Date (YYYY-MM-DD):");
        lblExpiry.setBounds(30, 350, 180, 25);
        add(lblExpiry);

        // Text fields and text area
        tfId = new JTextField();
        tfId.setBounds(180, 30, 200, 25);
        add(tfId);

        tfName = new JTextField();
        tfName.setBounds(180, 70, 200, 25);
        add(tfName);

        tfType = new JTextField();
        tfType.setBounds(180, 110, 200, 25);
        add(tfType);

        tfPrice = new JTextField();
        tfPrice.setBounds(180, 150, 200, 25);
        add(tfPrice);

        taDescription = new JTextArea();
        taDescription.setBounds(180, 190, 200, 100);
        taDescription.setLineWrap(true);
        taDescription.setWrapStyleWord(true);
        add(taDescription);

        tfQuantity = new JTextField();
        tfQuantity.setBounds(180, 310, 200, 25);
        add(tfQuantity);

        tfExpiry = new JTextField();
        tfExpiry.setBounds(180, 350, 200, 25);
        add(tfExpiry);

        // Buttons
        addBtn = new JButton("Add Medicine");
        addBtn.setBounds(80, 400, 130, 35);
        add(addBtn);

        backBtn = new JButton("Back");
        backBtn.setBounds(240, 400, 130, 35);
        add(backBtn);

        addBtn.addActionListener(this);
        backBtn.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addBtn) {
            String id = tfId.getText().trim();
            String name = tfName.getText().trim();
            String type = tfType.getText().trim();
            String priceStr = tfPrice.getText().trim();
            String description = taDescription.getText().trim();
            String quantityStr = tfQuantity.getText().trim();
            String expiry = tfExpiry.getText().trim();

            if (id.isEmpty() || name.isEmpty() || type.isEmpty() || priceStr.isEmpty()
                    || quantityStr.isEmpty() || expiry.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all required fields.");
                return;
            }

            try {
                double price = Double.parseDouble(priceStr);
                int quantity = Integer.parseInt(quantityStr);

                ConnectionClass obj = new ConnectionClass();

                String query = "INSERT INTO medicine (medicine_id, name, type, price, description, quantity, expiry_date) VALUES (?, ?, ?, ?, ?, ?, ?)";

                PreparedStatement pst = obj.con.prepareStatement(query);
                pst.setString(1, id);
                pst.setString(2, name);
                pst.setString(3, type);
                pst.setDouble(4, price);
                pst.setString(5, description);
                pst.setInt(6, quantity);
                pst.setDate(7, Date.valueOf(expiry));  // Assumes format YYYY-MM-DD

                int inserted = pst.executeUpdate();

                if (inserted > 0) {
                    JOptionPane.showMessageDialog(null, "Medicine added successfully!");
                    setVisible(false);
                    new MedicineCornerPage();
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to add medicine.");
                }

                pst.close();
                obj.con.close();

            } catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(null, "Please enter valid numeric values for price and quantity.");
            } catch (IllegalArgumentException iae) {
                JOptionPane.showMessageDialog(null, "Please enter a valid expiry date in the format YYYY-MM-DD.");
            } catch (SQLException se) {
                JOptionPane.showMessageDialog(null, "Database error: " + se.getMessage());
                se.printStackTrace();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        } else if (e.getSource() == backBtn) {
            setVisible(false);
            new MedicineCornerPage();
        }
    }

    public static void main(String[] args) {
        new AddMedicinePage();
    }
}
