package Hospital;

import javax.swing.*;

public class GuestPage extends JFrame {
    public GuestPage() {
        setTitle("Guest Mode - View Tips & Services");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JTextArea area = new JTextArea("Welcome to Vet Clinic!\n\nAs a guest, you can explore:\n- Pet Care Tips\n- Available Services\n\nPlease register or login to book an appointment.");
        area.setEditable(false);
        add(new JScrollPane(area));

        setVisible(true);
    }
}
